/**
 * Professional Portfolio Website Logic - Dharanika N
 */

document.addEventListener('DOMContentLoaded', () => {
    
    // ==========================================================================
    // 1. Navigation Menu & Scroll Management
    // ==========================================================================
    const navbar = document.getElementById('navbar');
    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
    const navMenu = document.getElementById('nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');
    const scrollToTopBtn = document.getElementById('scroll-to-top');

    // Sticky Navbar on Scroll
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }

        // Scroll to Top visibility
        if (window.scrollY > 400) {
            scrollToTopBtn.classList.add('active');
        } else {
            scrollToTopBtn.classList.remove('active');
        }
    });

    // Scroll to Top action
    scrollToTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    // Mobile Navigation Toggle
    mobileMenuToggle.addEventListener('click', () => {
        mobileMenuToggle.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Close mobile menu when clicking a link
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            mobileMenuToggle.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });

    // Active Navigation Highlighting based on Scroll Section Intersection
    const sections = document.querySelectorAll('section');
    const navObserverOptions = {
        root: null,
        threshold: 0.25, // Trigger when 25% of section is visible
        rootMargin: "-80px 0px 0px 0px" // Account for navigation height
    };

    const navObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const activeId = entry.target.getAttribute('id');
                navLinks.forEach(link => {
                    if (link.getAttribute('href') === `#${activeId}`) {
                        link.classList.add('active');
                    } else {
                        link.classList.remove('active');
                    }
                });
            }
        });
    }, navObserverOptions);

    sections.forEach(section => {
        if (section.getAttribute('id')) {
            navObserver.observe(section);
        }
    });


    // ==========================================================================
    // 2. Light / Dark Theme Management
    // ==========================================================================
    const themeToggle = document.getElementById('theme-toggle');
    const themeIconDark = themeToggle.querySelector('.theme-icon-dark');
    const themeIconLight = themeToggle.querySelector('.theme-icon-light');

    // Retrieve saved theme preference, defaulting to dark
    let currentTheme = localStorage.getItem('portfolio-theme') || 'dark';
    document.documentElement.setAttribute('data-theme', currentTheme);
    updateThemeIcons(currentTheme);

    themeToggle.addEventListener('click', () => {
        const targetTheme = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', targetTheme);
        localStorage.setItem('portfolio-theme', targetTheme);
        updateThemeIcons(targetTheme);
    });

    function updateThemeIcons(theme) {
        if (theme === 'dark') {
            themeIconDark.style.display = 'block';
            themeIconLight.style.display = 'none';
        } else {
            themeIconDark.style.display = 'none';
            themeIconLight.style.display = 'block';
        }
    }


    // ==========================================================================
    // 3. Typing Text Effect (Hero Section)
    // ==========================================================================
    const typingTextSpan = document.getElementById('typing-text');
    const roles = ["Full Stack Developer", "IoT Specialist", "IT Student", "Defence Tech Innovator"];
    const typingSpeed = 120;
    const erasingSpeed = 60;
    const nextRoleDelay = 2000;
    
    let roleIndex = 0;
    let charIndex = 0;

    function type() {
        if (typingTextSpan) {
            if (charIndex < roles[roleIndex].length) {
                typingTextSpan.textContent += roles[roleIndex].charAt(charIndex);
                charIndex++;
                setTimeout(type, typingSpeed);
            } else {
                setTimeout(erase, nextRoleDelay);
            }
        }
    }

    function erase() {
        if (typingTextSpan) {
            if (charIndex > 0) {
                typingTextSpan.textContent = roles[roleIndex].substring(0, charIndex - 1);
                charIndex--;
                setTimeout(erase, erasingSpeed);
            } else {
                roleIndex = (roleIndex + 1) % roles.length;
                setTimeout(type, typingSpeed + 300);
            }
        }
    }

    // Start typing effect with a slight delay
    if (typingTextSpan) {
        setTimeout(type, 1000);
    }


    // ==========================================================================
    // 3.5. Interactive Talking Avatar & Speech Synthesis
    // ==========================================================================
    const voiceIntroBtn = document.getElementById('voice-intro-btn');
    const speechBubble = document.getElementById('speech-bubble');
    const speechText = speechBubble ? speechBubble.querySelector('.speech-text') : null;
    const audioVisualizer = document.getElementById('audio-visualizer');
    const avatarCard = document.getElementById('interactive-avatar-card');

    const greetingText = "Hi! I am Dharanika N. I am a software developer and IT student. I specialize in full stack web development and embedded systems integration. I am looking forward to collaborating with you on your next project!";
    let isSpeaking = false;
    let speechUtterance = null;
    let typeBubbleTimeout = null;

    if (voiceIntroBtn && window.speechSynthesis) {
        voiceIntroBtn.addEventListener('click', (e) => {
            e.stopPropagation(); // Avoid triggering 3D tilt mouseleave reset
            
            if (isSpeaking) {
                stopGreetingSpeech();
            } else {
                startGreetingSpeech();
            }
        });
    }

    function startGreetingSpeech() {
        const synth = window.speechSynthesis;
        synth.cancel(); // Stop any active speech

        speechUtterance = new SpeechSynthesisUtterance(greetingText);
        
        // Find suitable natural English female voice
        const voices = synth.getVoices();
        let selectedVoice = voices.find(voice => 
            (voice.name.toLowerCase().includes('google') || 
             voice.name.toLowerCase().includes('natural') || 
             voice.name.toLowerCase().includes('female') || 
             voice.name.toLowerCase().includes('zira') || 
             voice.name.toLowerCase().includes('samantha') || 
             voice.name.toLowerCase().includes('hazel')) && 
            voice.lang.startsWith('en')
        );

        // Fallback: search for any english voice
        if (!selectedVoice) {
            selectedVoice = voices.find(voice => voice.lang.startsWith('en'));
        }

        if (selectedVoice) {
            speechUtterance.voice = selectedVoice;
        }

        speechUtterance.rate = 0.95; // Slightly slower for clear pronunciation
        speechUtterance.pitch = 1.05; // Friendly tone

        speechUtterance.onstart = () => {
            isSpeaking = true;
            avatarCard.classList.add('speaking');
            const gyroRings = document.getElementById('gyro-rings');
            if (gyroRings) gyroRings.classList.add('pulse-voice');
            speechBubble.classList.add('active');
            if (audioVisualizer) audioVisualizer.style.display = 'flex';
            voiceIntroBtn.innerHTML = '<i class="fa-solid fa-volume-xmark"></i> Stop';
            voiceIntroBtn.classList.add('speaking-btn');
            
            // Start typewriter display in speech bubble
            typeSpeechBubbleText(greetingText);
        };

        speechUtterance.onend = () => {
            stopGreetingSpeech();
        };

        speechUtterance.onerror = () => {
            stopGreetingSpeech();
        };

        synth.speak(speechUtterance);
    }

    function stopGreetingSpeech() {
        const synth = window.speechSynthesis;
        synth.cancel();
        isSpeaking = false;
        
        if (avatarCard) avatarCard.classList.remove('speaking');
        const gyroRings = document.getElementById('gyro-rings');
        if (gyroRings) gyroRings.classList.remove('pulse-voice');
        if (speechBubble) speechBubble.classList.remove('active');
        if (audioVisualizer) audioVisualizer.style.display = 'none';
        if (voiceIntroBtn) {
            voiceIntroBtn.innerHTML = '<i class="fa-solid fa-volume-high"></i> Play Greeting';
            voiceIntroBtn.classList.remove('speaking-btn');
        }
        
        if (typeBubbleTimeout) {
            clearTimeout(typeBubbleTimeout);
        }
        if (speechText) {
            speechText.textContent = '';
        }
    }

    function typeSpeechBubbleText(text) {
        if (!speechText) return;
        speechText.textContent = '';
        let index = 0;
        
        function nextChar() {
            if (index < text.length) {
                speechText.textContent += text.charAt(index);
                index++;
                // Synchronize speed with speaking rate
                typeBubbleTimeout = setTimeout(nextChar, 42);
            }
        }
        nextChar();
    }

    // Cancel speech on page unload to prevent phantom speaking
    window.addEventListener('beforeunload', () => {
        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
        }
    });


    // ==========================================================================
    // 4. Scroll Reveal Animator
    // ==========================================================================
    const revealElements = document.querySelectorAll('.reveal');
    const revealObserverOptions = {
        root: null,
        threshold: 0.1, // Trigger when 10% of element is in viewport
        rootMargin: "0px 0px -50px 0px" // Trigger slightly before screen bottom
    };

    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target); // Stop observing once revealed
            }
        });
    }, revealObserverOptions);

    revealElements.forEach(el => {
        revealObserver.observe(el);
    });


    // ==========================================================================
    // 5. Advanced 3D Parallax & Depth Tilt Engine (Hero Avatar 3D Stage)
    // ==========================================================================
    const avatarStage = document.getElementById('avatar-3d-stage');
    const heroAvatarImg = document.getElementById('hero-avatar');
    const avatarGlare = document.getElementById('avatar-glare');
    const floatingBadges = document.querySelectorAll('.floating-tech-badge');
    
    if (avatarCard) {
        let currentTiltX = 0;
        let currentTiltY = 0;
        let targetTiltX = 0;
        let targetTiltY = 0;
        let isHovered = false;
        let glareX = 50;
        let glareY = 50;

        const maxTilt = 18; // Maximum tilt in degrees
        const lerpFactor = 0.08; // Smooth damping coefficient

        // Mouse movement tracking on hero media
        const heroMedia = document.querySelector('.hero-media');
        const trackingZone = heroMedia || avatarCard;

        trackingZone.addEventListener('mousemove', (e) => {
            const rect = avatarCard.getBoundingClientRect();
            
            // Calculate cursor offset relative to center of card (-1 to 1)
            const mouseX = (e.clientX - rect.left) / rect.width;
            const mouseY = (e.clientY - rect.top) / rect.height;

            const normX = (mouseX - 0.5) * 2;
            const normY = (mouseY - 0.5) * 2;

            targetTiltX = -normY * maxTilt;
            targetTiltY = normX * maxTilt;

            // Specular glare coords (0% to 100%)
            glareX = mouseX * 100;
            glareY = mouseY * 100;

            isHovered = true;
            if (avatarGlare) {
                avatarGlare.style.opacity = '1';
                avatarGlare.style.background = `radial-gradient(circle at ${glareX}% ${glareY}%, rgba(255, 255, 255, 0.45) 0%, rgba(6, 182, 212, 0.18) 35%, transparent 70%)`;
            }
        });

        trackingZone.addEventListener('mouseleave', () => {
            targetTiltX = 0;
            targetTiltY = 0;
            isHovered = false;
            if (avatarGlare) {
                avatarGlare.style.opacity = '0';
            }
        });

        // Mobile Device Gyroscope / Orientation Support
        if (window.DeviceOrientationEvent && ('ontouchstart' in window || navigator.maxTouchPoints > 0)) {
            window.addEventListener('deviceorientation', (e) => {
                if (e.gamma !== null && e.beta !== null) {
                    // Gamma is left/right tilt [-90, 90], Beta is front/back tilt [-180, 180]
                    const clampedGamma = Math.max(-30, Math.min(30, e.gamma));
                    const clampedBeta = Math.max(-30, Math.min(30, e.beta - 40)); // Calibrate for handheld angle
                    
                    targetTiltY = (clampedGamma / 30) * maxTilt;
                    targetTiltX = (-clampedBeta / 30) * maxTilt;
                    isHovered = true;
                }
            }, false);
        }

        // Smooth physics render loop
        function update3DCardPhysics() {
            // Linear interpolation (Lerp) for butter-smooth motion
            currentTiltX += (targetTiltX - currentTiltX) * lerpFactor;
            currentTiltY += (targetTiltY - currentTiltY) * lerpFactor;

            // Apply 3D perspective transform to the card
            avatarCard.style.transform = `perspective(1200px) rotateX(${currentTiltX.toFixed(2)}deg) rotateY(${currentTiltY.toFixed(2)}deg) scale3d(1.02, 1.02, 1.02)`;
            
            // Dynamic box shadow following light source
            const shadowX = -currentTiltY * 1.8;
            const shadowY = currentTiltX * 1.8;
            avatarCard.style.boxShadow = `${shadowX}px ${shadowY}px 45px rgba(0, 0, 0, 0.65), 0 0 30px var(--accent-cyan-glow)`;

            // Depth Parallax for Floating Tech Badges
            floatingBadges.forEach(badge => {
                const depth = parseFloat(badge.getAttribute('data-depth')) || 70;
                // Deeper elements shift more in opposite direction
                const badgeShiftX = (-currentTiltY * (depth / 35)).toFixed(2);
                const badgeShiftY = (currentTiltX * (depth / 35)).toFixed(2);
                badge.style.transform = `translate3d(${badgeShiftX}px, ${badgeShiftY}px, ${depth}px)`;
            });

            requestAnimationFrame(update3DCardPhysics);
        }
        requestAnimationFrame(update3DCardPhysics);
    }


    // ==========================================================================
    // 6. Interactive Mouse Sparks & Cyber Particle Emitter (Avatar Canvas)
    // ==========================================================================
    const canvas = document.getElementById('sparkle-canvas');
    if (canvas && avatarCard) {
        const ctx = canvas.getContext('2d');
        let particles = [];

        // Sync canvas size
        function resizeCanvas() {
            canvas.width = avatarCard.offsetWidth;
            canvas.height = avatarCard.offsetHeight;
        }
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);

        class Particle {
            constructor(x, y, isBurst = false) {
                this.x = x;
                this.y = y;
                this.size = Math.random() * (isBurst ? 3 : 2) + 1;
                const speedMult = isBurst ? 3.5 : 1.2;
                const angle = Math.random() * Math.PI * 2;
                this.speedX = Math.cos(angle) * Math.random() * speedMult;
                this.speedY = Math.sin(angle) * Math.random() * speedMult - (isBurst ? 0 : 0.8);
                this.alpha = 1;
                this.decay = Math.random() * 0.02 + (isBurst ? 0.015 : 0.025);
                
                // Cyan to Violet color gradients
                const hues = [180, 200, 260, 280];
                this.hue = hues[Math.floor(Math.random() * hues.length)];
            }

            update() {
                this.x += this.speedX;
                this.y += this.speedY;
                this.alpha -= this.decay;
            }

            draw() {
                ctx.save();
                ctx.globalAlpha = Math.max(0, this.alpha);
                ctx.shadowBlur = 10;
                ctx.shadowColor = `hsla(${this.hue}, 100%, 50%, ${this.alpha})`;
                ctx.fillStyle = `hsla(${this.hue}, 100%, 75%, ${this.alpha})`;
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();
            }
        }

        // Spawn particles on mousemove
        avatarCard.addEventListener('mousemove', (e) => {
            const rect = canvas.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;

            for (let i = 0; i < 2; i++) {
                particles.push(new Particle(mouseX, mouseY));
            }
        });

        // Click on 3D Avatar card triggers high-energy particle burst!
        avatarCard.addEventListener('click', (e) => {
            const rect = canvas.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;

            for (let i = 0; i < 20; i++) {
                particles.push(new Particle(mouseX, mouseY, true));
            }
        });

        function animateParticles() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            for (let i = 0; i < particles.length; i++) {
                particles[i].update();
                particles[i].draw();

                if (particles[i].alpha <= 0) {
                    particles.splice(i, 1);
                    i--;
                }
            }
            requestAnimationFrame(animateParticles);
        }
        requestAnimationFrame(animateParticles);
    }


    // ==========================================================================
    // 6.5. 3D Avatar Customizer & Personal Photo System
    // ==========================================================================
    const btnModePhoto = document.getElementById('btn-mode-photo');
    const btnModeAvatar = document.getElementById('btn-mode-avatar');
    const btnModeCyber = document.getElementById('btn-mode-cyber');
    const btnModeUpload = document.getElementById('btn-mode-upload');
    const fileUploadInput = document.getElementById('avatar-file-upload');
    const modeButtons = [btnModePhoto, btnModeAvatar, btnModeCyber, btnModeUpload].filter(Boolean);

    const realPhotoSrc = 'assets/dharanika.jpeg';
    const stylizedAvatarSrc = 'assets/avatar_female.png';
    const cyberAvatarSrc = 'assets/avatar.png';

    // Helper: switch active mode button
    function setActiveModeButton(activeBtn) {
        modeButtons.forEach(btn => btn.classList.remove('active'));
        if (activeBtn) activeBtn.classList.add('active');
    }

    // 1. My Real Photo Mode (Default & Permanent)
    if (btnModePhoto) {
        btnModePhoto.addEventListener('click', () => {
            if (heroAvatarImg) heroAvatarImg.src = realPhotoSrc;
            setActiveModeButton(btnModePhoto);
            localStorage.setItem('dharanika-avatar-selection', 'photo');
        });
    }

    // 2. Stylized 3D Character Mode
    if (btnModeAvatar) {
        btnModeAvatar.addEventListener('click', () => {
            if (heroAvatarImg) heroAvatarImg.src = stylizedAvatarSrc;
            setActiveModeButton(btnModeAvatar);
            localStorage.setItem('dharanika-avatar-selection', 'avatar');
        });
    }

    // 3. Cyber 3D Workstation Mode
    if (btnModeCyber) {
        btnModeCyber.addEventListener('click', () => {
            if (heroAvatarImg) heroAvatarImg.src = cyberAvatarSrc;
            setActiveModeButton(btnModeCyber);
            localStorage.setItem('dharanika-avatar-selection', 'cyber');
        });
    }

    // 4. Upload Custom Photo Mode
    if (btnModeUpload && fileUploadInput) {
        btnModeUpload.addEventListener('click', () => {
            fileUploadInput.click();
        });

        fileUploadInput.addEventListener('change', (e) => {
            const file = e.target.files && e.target.files[0];
            if (file) {
                if (!file.type.startsWith('image/')) {
                    alert('Please select a valid image file (PNG, JPG, WebP).');
                    return;
                }

                const reader = new FileReader();
                reader.onload = (event) => {
                    const customDataUrl = event.target.result;
                    if (heroAvatarImg) heroAvatarImg.src = customDataUrl;
                    
                    try {
                        localStorage.setItem('dharanika-custom-photo', customDataUrl);
                        localStorage.setItem('dharanika-avatar-selection', 'custom');
                    } catch (err) {
                        console.warn('Image size too large for localStorage quota:', err);
                    }

                    setActiveModeButton(btnModeUpload);
                };
                reader.readAsDataURL(file);
            }
        });
    }

    // Restore saved avatar preference or default to real photo permanently
    let savedAvatarSelection = localStorage.getItem('dharanika-avatar-selection');
    if (savedAvatarSelection === 'default') {
        localStorage.removeItem('dharanika-avatar-selection');
        savedAvatarSelection = null;
    }
    const savedCustomPhoto = localStorage.getItem('dharanika-custom-photo');

    if (savedAvatarSelection === 'custom' && savedCustomPhoto && heroAvatarImg) {
        heroAvatarImg.src = savedCustomPhoto;
        setActiveModeButton(btnModeUpload);
    } else if (savedAvatarSelection === 'avatar' && heroAvatarImg) {
        heroAvatarImg.src = stylizedAvatarSrc;
        setActiveModeButton(btnModeAvatar);
    } else if (savedAvatarSelection === 'cyber' && heroAvatarImg) {
        heroAvatarImg.src = cyberAvatarSrc;
        setActiveModeButton(btnModeCyber);
    } else if (heroAvatarImg) {
        heroAvatarImg.src = realPhotoSrc;
        setActiveModeButton(btnModePhoto);
    }


    // ==========================================================================
    // 7. Skills Tabs Management
    // ==========================================================================
    const tabButtons = document.querySelectorAll('.skills-tab-btn');
    const skillPanes = document.querySelectorAll('.skills-pane');

    tabButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            // Remove active class from buttons and panes
            tabButtons.forEach(b => b.classList.remove('active'));
            skillPanes.forEach(p => p.classList.remove('active'));

            // Activate current tab button
            btn.classList.add('active');

            // Activate corresponding pane
            const category = btn.getAttribute('data-skill-cat');
            document.getElementById(`skills-${category}`).classList.add('active');
        });
    });


    // ==========================================================================
    // 8. Portfolio Projects Filters
    // ==========================================================================
    const filterButtons = document.querySelectorAll('.filter-btn');
    const projectCards = document.querySelectorAll('.project-card');

    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            // Reset active button class
            filterButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const filterValue = btn.getAttribute('data-filter');

            projectCards.forEach(card => {
                const category = card.getAttribute('data-category');
                
                // Add scale transitions
                card.style.transition = 'transform 0.4s ease, opacity 0.4s ease';

                if (filterValue === 'all' || category === filterValue) {
                    card.style.display = 'flex';
                    // Re-trigger visual entry scale
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'scale(1)';
                    }, 50);
                } else {
                    card.style.opacity = '0';
                    card.style.transform = 'scale(0.8)';
                    setTimeout(() => {
                        card.style.display = 'none';
                    }, 350); // Delay match with transitions
                }
            });
        });
    });


    // ==========================================================================
    // 9. Project Database & Details Modal Component
    // ==========================================================================
    
    // Project Static Database
    const projectsData = {
        "1": {
            title: "Landmine Detection System with Smart Shoe",
            category: "IoT / Embedded Systems",
            visualClass: "gradient-1",
            iconClass: "fa-solid fa-shoe-prints",
            tags: ["Arduino Uno", "Ultrasonic & Proximity Sensors", "Defence Tech"],
            desc: "Designed and engineered a wearable smart shoe prototype embedded with microcontrollers and custom proximity/metal sensors to detect buried landmines in real-time. Created specifically for defense-critical applications, it integrates an automated safety warning buzzer alert subsystem.",
            features: [
                "Real-time signal parsing from electromagnetic proximity sensors",
                "Embedded Arduino control logic handling sensory inputs",
                "Automated buzzer alert feedback loop triggered upon mine detection",
                "Won First Place at Nandha Engineering College Technical Hackathon"
            ],
            demoUrl: "https://github.com/Dharanika-N",
            repoUrl: "https://github.com/Dharanika-N"
        },
        "2": {
            title: "AetherCards - Smart AI Flashcard Generator",
            category: "Web Application",
            visualClass: "gradient-2",
            iconClass: "fa-solid fa-brain",
            tags: ["React.js", "FastAPI (Python)", "NLP (NLTK)", "Leitner Spaced Repetition"],
            desc: "Developed a full-stack study assistant application that automatically extracts key terms and contextual definitions from textual source material using a localized Natural Language Processing (NLP) pipeline. Manages flashcard review scheduling using an optimized Leitner Spaced Repetition algorithm.",
            features: [
                "NLP tokenization and extraction pipelines running NLTK libraries",
                "Automated spaced repetition algorithms tracking student progress cycles",
                "High-performance FastAPI Python server handling logic endpoints",
                "Responsive React.js design styled with modern interactive card components"
            ],
            demoUrl: "https://github.com/Dharanika-N",
            repoUrl: "https://github.com/Dharanika-N"
        },
        "3": {
            title: "Smart Dustbin with Automatic Lid Opening",
            category: "IoT / Embedded Systems",
            visualClass: "gradient-3",
            iconClass: "fa-solid fa-trash-can",
            tags: ["Arduino", "Ultrasonic Motion Sensor", "Servo Motor"],
            desc: "Built a fully automated touchless smart wastebin utilizing an Arduino microcontroller board. Uses ultrasonic range-finding sensors to detect incoming movements, automatically opening the lid via a high-torque servo motor subsystem to guarantee hands-free hygienic waste disposal.",
            features: [
                "Proximity triggers based on continuous ultrasonic signal reflection analysis",
                "Precise servo motor angular acceleration controls for soft lid opening",
                "Optimized low-power idle configuration for standalone battery life",
                "Designed and verified custom breadboard layouts for micro-hardware stability"
            ],
            demoUrl: "https://github.com/Dharanika-N",
            repoUrl: "https://github.com/Dharanika-N"
        }
    };

    const modal = document.getElementById('project-modal');
    const modalContent = document.getElementById('modal-body-content');
    const modalCloseBtn = document.getElementById('modal-close');
    const modalBackdrop = document.getElementById('modal-backdrop');
    const detailButtons = document.querySelectorAll('.btn-card-details');

    // Open Modal
    detailButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const projectId = btn.getAttribute('data-project-id');
            const data = projectsData[projectId];

            if (data) {
                populateModal(data);
                modal.classList.add('active');
                document.body.style.overflow = 'hidden'; // Stop background scrolling
            }
        });
    });

    // Close Modal
    function closeModal() {
        modal.classList.remove('active');
        document.body.style.overflow = 'auto'; // Re-enable background scrolling
    }

    if (modalCloseBtn) modalCloseBtn.addEventListener('click', closeModal);
    if (modalBackdrop) modalBackdrop.addEventListener('click', closeModal);

    // Escape Key Close
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.classList.contains('active')) {
            closeModal();
        }
    });

    // Populate Modal Content Dynamically
    function populateModal(data) {
        // Build tags markup
        const tagsHtml = data.tags.map(tag => `<span class="tag">${tag}</span>`).join('');
        
        // Build features list markup
        const featuresHtml = data.features.map(f => `<li><i class="fa-solid fa-check" style="color: var(--accent-cyan); margin-right: 10px;"></i> ${f}</li>`).join('');

        modalContent.innerHTML = `
            <div class="modal-visual-placeholder ${data.visualClass}">
                <i class="${data.iconClass}" style="font-size: 5rem; color: rgba(255, 255, 255, 0.25);"></i>
            </div>
            
            <h3 class="modal-title">${data.title}</h3>
            
            <div class="modal-tech-stack">
                ${tagsHtml}
            </div>
            
            <p class="modal-desc">${data.desc}</p>
            
            <div style="margin-bottom: 30px;">
                <h4 style="font-family: var(--font-heading); margin-bottom: 12px; font-weight: 700;">Key Implementation Achievements</h4>
                <ul style="list-style: none; display: flex; flex-direction: column; gap: 8px; font-size: 0.95rem; color: var(--text-secondary);">
                    ${featuresHtml}
                </ul>
            </div>
            
            <div class="modal-actions" style="display: flex; gap: 14px; flex-wrap: wrap;">
                <a href="${data.repoUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-primary">View on GitHub <i class="fa-brands fa-github"></i></a>
                <a href="https://www.linkedin.com/in/dharanika-n/" target="_blank" rel="noopener noreferrer" class="btn btn-secondary">Connect on LinkedIn <i class="fa-brands fa-linkedin-in"></i></a>
            </div>
        `;
    }


    // ==========================================================================
    // 10. Contact Form Simulation
    // ==========================================================================
    const contactForm = document.getElementById('portfolio-contact-form');
    const formSuccessMessage = document.getElementById('form-success');
    const submitBtn = document.getElementById('contact-submit-btn');

    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            // Check if running on local file system (which blocks CORS AJAX requests)
            const isLocalFile = window.location.protocol === 'file:';

            if (isLocalFile) {
                // Let standard HTML form submit and redirect to FormSubmit.co page
                contactForm.action = "https://formsubmit.co/dharanikadharani2301@gmail.com";
                contactForm.method = "POST";
                alert("Note: Because you are viewing this page locally from your computer (file://), we will submit the form using a standard redirect. Please check your email inbox to activate FormSubmit on your first message submission!");
                return; // Let standard form submission proceed (do not call e.preventDefault())
            }

            e.preventDefault();

            // Simple submission visual response
            submitBtn.disabled = true;
            submitBtn.innerHTML = 'Sending... <i class="fa-solid fa-spinner fa-spin"></i>';

            const nameVal = document.getElementById('contact-name').value;
            const emailVal = document.getElementById('contact-email').value;
            const subjectVal = document.getElementById('contact-subject').value;
            const messageVal = document.getElementById('contact-message').value;

            // Submit using FormSubmit AJAX endpoint (works when hosted online)
            fetch("https://formsubmit.co/ajax/dharanikadharani2301@gmail.com", {
                method: "POST",
                headers: { 
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    Name: nameVal,
                    Email: emailVal,
                    Subject: subjectVal,
                    Message: messageVal
                })
            })
            .then(response => response.json())
            .then(data => {
                // Hide form content and render success animation screen
                contactForm.style.display = 'none';
                formSuccessMessage.style.display = 'block';
            })
            .catch(error => {
                console.error('Error submitting form via AJAX:', error);
                submitBtn.disabled = false;
                submitBtn.innerHTML = 'Send Message <i class="fa-regular fa-paper-plane"></i>';
                
                // Fallback: Submit using standard redirect post
                alert('AJAX request failed. Redirecting to standard form submission...');
                contactForm.action = "https://formsubmit.co/dharanikadharani2301@gmail.com";
                contactForm.method = "POST";
                contactForm.submit();
            });
        });
    }

});
